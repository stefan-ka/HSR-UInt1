package dl;


public interface Dto<T> {

	public void setData(T newData);

}